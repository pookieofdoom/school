#define F_CPU 16000000UL
#include <avr/io.h>
#include<avr/wdt.h>
#include<avr/interrupt.h>
#include<util/delay.h>
#include <stdlib.h>
#include "usart.h"
#include "ee24c04.h"


FILE usart0_str = FDEV_SETUP_STREAM(USART0SendByte, USART0ReceiveByte, _FDEV_SETUP_RW);
volatile char flagLED = 1;
volatile unsigned int ledCounter = 0;
volatile unsigned int ledFreq = 10;


void sendTrigger () {
	
	PORTC &= ~(1<<PC1);
	_delay_us(2);
	PORTC |= (1<<PC1);
	_delay_us(5);
	PORTC &= ~(1<<PC1);
}

void sendTrigger2 () {
	
	PORTC &= ~(1<<PC5);
	_delay_us(2);
	PORTC |= (1<<PC5);
	_delay_us(5);
	PORTC &= ~(1<<PC5);
}

long microsecondsToCentimeters(long microseconds)
{
	// The speed of sound is 340 m/s or 29 microseconds per centimeter.
	// The ping travels out and back, so to find the distance of the
	// object we take half of the distance travelled.
	return microseconds / 29 / 2;
}



unsigned long getDuration () {
	unsigned long pulseCount = 0;
	unsigned long loopCount = 0;
	unsigned long loopMax = 3000;
	
	// While the pin is *not* in the target state we make sure the timeout hasn't been reached.
	while (((PINC>>PC4) & 1) != 1) {
		if (loopCount++ == loopMax) {
			return 0;
		}
	}
	
	// When the pin *is* in the target state we bump the counter while still keeping track of the timeout.
	while (((PINC>>PC4) & 1) == 1) {
		if (loopCount++ == loopMax) {
			return 0;
		}
		pulseCount++;
	}
	
	// Return the pulse time in microsecond!
	return pulseCount * 1.455;
	
}

unsigned long getDuration2 () 
{
	unsigned long pulseCount = 0;
	unsigned long loopCount = 0;
	unsigned long loopMax = 3000;
	
	// While the pin is *not* in the target state we make sure the timeout hasn't been reached.
	while (((PINB>>PB5) & 1) != 1) {
		if (loopCount++ == loopMax) {
			return 0;
		}
	}
	
	// When the pin *is* in the target state we bump the counter while still keeping track of the timeout.
	while (((PINB>>PB5) & 1) == 1) {
		if (loopCount++ == loopMax) {
			return 0;
		}
		pulseCount++;
	}
	
	// Return the pulse time in microsecond!
	return pulseCount * 1.455;
	
}

void lcd_wr_cmd(char cmd) // function set
{
	PORTB = 0b00000000; // 0, 0, 0
	PORTD = cmd; //function set

	_delay_us(1); // tw delay
	PORTB = 0b00000100; // 1, 0 ,0 ( E is high)
	PORTB = 0b00000000; // 0, 0 ,0 (E go low again)

}

void lcd_init(void)
{
	_delay_ms(1);
	_delay_ms(40); // can be tuned down to be 20
	lcd_wr_cmd(0x38); // function set command
	_delay_us(80);
	lcd_wr_cmd(0x0C); //display set
	_delay_us(80);
	lcd_wr_cmd(0x06); //enable set
	_delay_us(80);
	//lcd_wr_custom(0, myHeart); //write to the CG RAM

}

void lcd_wr_char(char character)
{
	PORTB = 0b00000000;
	PORTD = character; //display character
	PORTB = 0b00000001; // 0, 0, 1
	_delay_us(1); // tw delay
	PORTB = 0b00000101; // 1, 0 ,1
	PORTB = 0b00000001; // 0, 0 ,1
	_delay_ms(1);

}


void lcd_display_hello_world(long distance)
{
	char my_string[7];
	ltoa(distance, my_string, 10);

	if(distance <100 && distance > 9)
	{
		for(int i = 0; i<2;i++)
		{
			lcd_wr_char(my_string[i]);
		}
	}	
	else if (distance <10)
	{
		for(int i = 0; i<1;i++)
		{
			lcd_wr_char(my_string[i]);
		}
	}


}


void display_count(int count_input)
{
	char count_string[7];
char unit_message[] = {'e','n','t','e','r','e','d'};
itoa(count_input,count_string,10);
//lcd_wr_cmd(0x01);
_delay_ms(100);
if(count_input < 10)
{
	for(int i=0; i<1; i++)
	{
		lcd_wr_char(count_string[i]);
		// _delay_ms(100);
	}
}
else if (count_input < 100)
{
	for(int i=0; i<2; i++)
	{
		lcd_wr_char(count_string[i]);
		// _delay_ms(100);
	}
	
}
else
{
	for(int i =0; i<3; i++)
	{
		lcd_wr_char(count_string[i]);
	}
}

lcd_wr_char(' ');
// _delay_ms(100);

for(int i=0; i<7;i++)
{
	lcd_wr_char(unit_message[i]);
	_delay_ms(100);
}

}

int main() {
	
	//
	
	//assign our stream to standard I/O streams34
	USART0Init();
	
	long duration,duration2, cm2, cm;
	char flag = 'a';
	DDRC |= (1<<PC1); //OUTPUT TRIGGER
	DDRC &= ~(1<<PC4); //INPUT ECHO
	
	DDRC |= (1<<PC2); //OUTPUT LED
	
	
	
	DDRC |= (1<< PC5); //trigger 2
	DDRB &= ~(1 << PB5); //inpt ehco2
	DDRC |= (1<< PC3);
	
	
	lcd_init();
	DDRB = 0b00000111; //E, RW,RS for LCD
	 DDRD = 0xFF; //LCD inputs
	stdin=stdout=&usart0_str;
	
	
	sei();
	
	while (1) {



		sendTrigger2();
		duration2 = getDuration2();
		sendTrigger();
		duration = getDuration();

		//duration = getDuration();

		cm = microsecondsToCentimeters(duration);
		cm2 = microsecondsToCentimeters(duration2);
		
		_delay_ms(50);
		
    lcd_wr_cmd(0x01);
    _delay_ms(100);
    lcd_display_hello_world(cm2);
    _delay_ms(100);
	printf("DIST: %d cm\n", cm);
	printf("DIST2: %d cm2\n", cm2);
/*
	  
	  if(count == 1000)
	  {
		  count = 0;
	  }
	  
	  if(count != current_count)
	  {
		  current_count = count;
		  lcd_wr_cmd(0x01);
		  //display_count(count);
		  printf("Entered: %d \n", count);
		  PORTC &= ~(1 << PC2);
		  PORTC &= ~(1 << PC3);
		  
	  }
	*/
	}	
}
