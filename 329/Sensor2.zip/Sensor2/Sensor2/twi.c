/*
 * twi.c
 *
 * Created: 1/7/2012 23:06:28
 *  Author: embedds.com
*/
#include "twi.h"

void setLEDstate( char cState )  {  // DEBUG
	//==============================================================================
	// set the LED to ON/OFF state cState
	// Arduino digital pin 13 = ATmega PortB.5
	
	if ( cState )
	PORTB |= BIT(PB5);    	// write a 1 to PB5 to turn LED ON
	else
	PORTB &= ~BIT(PB5);     // turn led OFF
}

void TWIInit(void)  {
	//set SCL to 200kHz: TWBR = 32, no prescale
	TWSR = 0x00;        // prescale in 1:0
	TWBR = 0x20;        // bit rate divider in 7:0
	TWCR = BIT(TWEN);   // enable TWI
}

void TWIclrTWINTandWait(void) {
	// new 150421
	TWCR = BIT(TWINT) | BIT(TWEN);   // clear TWINT
	while( !(TWCR & BIT(TWINT)) ) ;  // wait
}

void TWIjustWait(void) {
	// new 150421
	// do not clear TWINT, just wait
	while( !(TWCR & BIT(TWINT)) ) ;  // wait
}

void TWIStart(void)  {
	//send start signal	
	//TWCR |= ( BIT(TWSTA) | BIT(TWEN));
	//TWCR |= ( BIT(TWINT) );
	TWCR = ( BIT(TWSTA) | BIT(TWEN) | BIT(TWINT) );
	//status = TWSR & 0xF8;
}

void TWIStop(void)  {
	//send stop signal
	TWCR |= (BIT(TWINT) | BIT(TWSTO) | BIT(TWEN));
}

void TWIWrite(uint8_t u8data) {
	// transmit a Byte
	TWDR = u8data;
	TWCR &= ~BIT(TWINT);
	//TWCR = (1<<TWINT)|(1<<TWEN);
	while (!(TWCR & BIT(TWINT)))
		;
}

//read byte with ACK
uint8_t TWIReadACK(void)  {
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWEA);
	while ((TWCR & (1<<TWINT)) == 0);
	return TWDR;
}

//read byte with NACK
uint8_t TWIReadNACK(void)  {
	TWCR = (1<<TWINT)|(1<<TWEN);
	while ((TWCR & (1<<TWINT)) == 0);
	return TWDR;
}

uint8_t TWIGetStatus(void)  {
	// return masked value of TWSR register
	uint8_t status;
	status = TWSR & 0xF8;  // mask out prescaler bits
	return status;
}