/*
 * twi.h
 *
 * Created: 1/7/2012 23:06:09
 *  Author: embedds.com
 */ 


#ifndef TWI_H_
#define TWI_H_
#include <avr/io.h>
#include <util/delay.h>    // software delay functions


#define BIT(x)	(1 << (x))  // bit pos'n

void setLEDstate( char cState );
void TWIInit(void);
void TWIclrTWINTandWait(void);
void TWIjustWait(void);
void TWIStart(void);
void TWIStop(void);
void TWIWrite(uint8_t u8data);
uint8_t TWIReadACK(void);
uint8_t TWIReadNACK(void);
uint8_t TWIGetStatus(void);



#endif /* TWI_H_ */