-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- AIRLINES-cleanup.sql


DROP TABLE Flights;
DROP TABLE Airlines;
DROP TABLE Airports100;
