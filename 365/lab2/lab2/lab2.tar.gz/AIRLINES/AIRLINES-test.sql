-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- AIRLINES-test.sql

SELECT * FROM Airports100;
SELECT COUNT(*) FROM Airports100;

SELECT * FROM Airlines;
SELECT COUNT(*) FROM Airlines;

SELECT * FROM Flights;
SELECT COUNT(*) FROM Flights;