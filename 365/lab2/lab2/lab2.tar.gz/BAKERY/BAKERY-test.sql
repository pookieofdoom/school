-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- BAKERY-cleanup.sql

SELECT * FROM Goods;
SELECT COUNT(*) FROM Goods;

SELECT * FROM Customers;
SELECT COUNT(*) FROM Customers;

SELECT * FROM Receipts;
SELECT COUNT(*) FROM Receipts;

SELECT * FROM Items;
SELECT COUNT(*) FROM Items;