-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CARS-test.sql


SELECT * FROM Continents;
SELECT COUNT(*) FROM Continents;

SELECT * FROM Countries;
SELECT COUNT(*) FROM Countries;

SELECT * FROM CarMakers;
SELECT COUNT(*) FROM CarMakers;

SELECT * FROM ModelList;
SELECT COUNT(*) FROM ModelList;

SELECT * FROM CarNames;
SELECT COUNT(*) FROM CarNames;

SELECT * FROM CarsData;
SELECT COUNT(*) FROM CarsData;