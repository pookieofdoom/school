-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CSU-cleanup.sql

DROP TABLE CSUFees;
DROP TABLE Faculty;
DROP TABLE Enrollments;
DROP TABLE DisciplineEnrollments;
DROP TABLE Degrees;
DROP TABLE Disciplines;
DROP TABLE Campuses;
