-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CSU-test.sql

SELECT * FROM Campuses;
SELECT COUNT(*) FROM Campuses;

SELECT * FROM Disciplines;
SELECT COUNT(*) FROM Disciplines;

SELECT * FROM Degrees;
SELECT COUNT(*) FROM Degrees;

SELECT * FROM DisciplineEnrollments;
SELECT COUNT(*) FROM DisciplineEnrollments;

SELECT * FROM Enrollments;
SELECT COUNT(*) FROM Enrollments;

SELECT * FROM Faculty;
SELECT COUNT(*) FROM Faculty;

SELECT * FROM CSUFees;
SELECT COUNT(*) FROM CSUFees;

