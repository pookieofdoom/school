-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- KATZENJAMMER-test.sql

SELECT * FROM Band;
SELECT COUNT(*) FROM Band;

SELECT * FROM Songs;
SELECT COUNT(*) FROM Songs;

SELECT * FROM Albums;
SELECT COUNT(*) FROM Albums;

SELECT * FROM Tracklists;
SELECT COUNT(*) FROM Tracklists;

SELECT * FROM Instruments;
SELECT COUNT(*) FROM Instruments;

SELECT * FROM Performance;
SELECT COUNT(*) FROM Performance;

SELECT * FROM Vocals;
SELECT COUNT(*) FROM Vocals;