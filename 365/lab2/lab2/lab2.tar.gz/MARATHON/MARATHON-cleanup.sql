-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE365
-- MARATHON-cleanup.sql

DROP TABLE Marathon;