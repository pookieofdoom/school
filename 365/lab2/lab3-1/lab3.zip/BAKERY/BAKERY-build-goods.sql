-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- BAKERY-build-goods.sql

INSERT INTO Goods VALUES('20-BC-C-10', 'Chocolate', 'Cake', 8.95);
INSERT INTO Goods VALUES('20-BC-L-10', 'Lemon', 'Cake', 8.95);
INSERT INTO Goods VALUES('20-CA-7.5', 'Casino', 'Cake', 15.95);
INSERT INTO Goods VALUES('24-8x10', 'Opera', 'Cake', 15.95);
INSERT INTO Goods VALUES('25-STR-9', 'Strawberry', 'Cake', 11.95);
INSERT INTO Goods VALUES('26-8x10', 'Truffle', 'Cake', 15.95);
INSERT INTO Goods VALUES('45-CH', 'Chocolate', 'Eclair', 3.25);
INSERT INTO Goods VALUES('45-CO', 'Coffee', 'Eclair', 3.5);
INSERT INTO Goods VALUES('45-VA', 'Vanilla', 'Eclair', 3.25);
INSERT INTO Goods VALUES('46-11', 'Napoleon', 'Cake', 13.49);
INSERT INTO Goods VALUES('90-ALM-I', 'Almond', 'Tart', 3.75);
INSERT INTO Goods VALUES('90-APIE-10', 'Apple', 'Pie', 5.25);
INSERT INTO Goods VALUES('90-APP-11', 'Apple', 'Tart', 3.25);
INSERT INTO Goods VALUES('90-APR-PF', 'Apricot', 'Tart', 3.25);
INSERT INTO Goods VALUES('90-BER-11', 'Berry', 'Tart', 3.25);
INSERT INTO Goods VALUES('90-BLK-PF', 'Blackberry', 'Tart', 3.25);
INSERT INTO Goods VALUES('90-BLU-11', 'Blueberry', 'Tart', 3.25);
INSERT INTO Goods VALUES('90-CH-PF', 'Chocolate', 'Tart', 3.75);
INSERT INTO Goods VALUES('90-CHR-11', 'Cherry', 'Tart', 3.25);
INSERT INTO Goods VALUES('90-LEM-11', 'Lemon', 'Tart', 3.25);
INSERT INTO Goods VALUES('90-PEC-11', 'Pecan', 'Tart', 3.75);
INSERT INTO Goods VALUES('70-GA', 'Ganache', 'Cookie', 1.15);
INSERT INTO Goods VALUES('70-GON', 'Gongolais', 'Cookie', 1.15);
INSERT INTO Goods VALUES('70-R', 'Raspberry', 'Cookie', 1.09);
INSERT INTO Goods VALUES('70-LEM', 'Lemon', 'Cookie', 0.79);
INSERT INTO Goods VALUES('70-M-CH-DZ', 'Chocolate', 'Meringue', 1.25);
INSERT INTO Goods VALUES('70-M-VA-SM-DZ', 'Vanilla', 'Meringue', 1.15);
INSERT INTO Goods VALUES('70-MAR', 'Marzipan', 'Cookie', 1.25);
INSERT INTO Goods VALUES('70-TU', 'Tuile', 'Cookie', 1.25);
INSERT INTO Goods VALUES('70-W', 'Walnut', 'Cookie', 0.79);
INSERT INTO Goods VALUES('50-ALM', 'Almond', 'Croissant', 1.45);
INSERT INTO Goods VALUES('50-APP', 'Apple', 'Croissant', 1.45);
INSERT INTO Goods VALUES('50-APR', 'Apricot', 'Croissant', 1.45);
INSERT INTO Goods VALUES('50-CHS', 'Cheese', 'Croissant', 1.75);
INSERT INTO Goods VALUES('50-CH', 'Chocolate', 'Croissant', 1.75);
INSERT INTO Goods VALUES('51-APR', 'Apricot', 'Danish', 1.15);
INSERT INTO Goods VALUES('51-APP', 'Apple', 'Danish', 1.15);
INSERT INTO Goods VALUES('51-ATW', 'Almond', 'Twist', 1.15);
INSERT INTO Goods VALUES('51-BC', 'Almond', 'Bear Claw', 1.95);
INSERT INTO Goods VALUES('51-BLU', 'Blueberry', 'Danish', 1.15);
