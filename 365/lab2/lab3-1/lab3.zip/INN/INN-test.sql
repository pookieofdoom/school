-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- INN-test.sql

SELECT * FROM Rooms;
SELECT COUNT(*) FROM Rooms;

SELECT * FROM Reservations;
SELECT COUNT(*) FROM Reservations;