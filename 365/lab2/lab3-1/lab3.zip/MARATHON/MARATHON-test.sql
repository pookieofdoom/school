-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- MARATHON-test.sql

SELECT * FROM Marathon;
SELECT COUNT(*) FROM Marathon;