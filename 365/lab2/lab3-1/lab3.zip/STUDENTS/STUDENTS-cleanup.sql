-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- STUDENTS-setup.sql

DROP TABLE List;
DROP TABLE Teachers;