-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- WINE-cleanup.sql

DROP TABLE Wine;
DROP TABLE Appellations;
DROP TABLE Grapes;