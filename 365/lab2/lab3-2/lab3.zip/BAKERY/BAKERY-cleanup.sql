-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- BAKERY-cleanup.sql

DROP TABLE Items;
DROP TABLE Receipts;
DROP TABLE Customers;
DROP TABLE Goods;