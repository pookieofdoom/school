-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- KATZENJAMMER-build-Band.sql

INSERT INTO Band VALUES(1, 'Solveig', 'Heilo');
INSERT INTO Band VALUES(2, 'Marianne', 'Sveen');
INSERT INTO Band VALUES(3, 'Anne-Marit', 'Bergheim');
INSERT INTO Band VALUES(4, 'Turid', 'Jorgensen');
