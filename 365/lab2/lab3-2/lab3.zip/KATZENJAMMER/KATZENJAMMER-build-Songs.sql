-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- KATZENJAMMER-build-Songs.sql

INSERT INTO Songs VALUES(1, 'Overture');
INSERT INTO Songs VALUES(2, 'A Bar In Amsterdam');
INSERT INTO Songs VALUES(3, 'Demon Kitty Rag');
INSERT INTO Songs VALUES(4, 'Tea With Cinnamon');
INSERT INTO Songs VALUES(5, 'Hey Ho on the Devil''s Back');
INSERT INTO Songs VALUES(6, 'Wading in Deeper');
INSERT INTO Songs VALUES(7, 'Le Pop');
INSERT INTO Songs VALUES(8, 'Der Kapitan');
INSERT INTO Songs VALUES(9, 'Virginia Clemm');
INSERT INTO Songs VALUES(10, 'Play My Darling,   Play');
INSERT INTO Songs VALUES(11, 'To the Sea');
INSERT INTO Songs VALUES(12, 'Mother Superior');
INSERT INTO Songs VALUES(13, 'Ain\'t no Thang');
INSERT INTO Songs VALUES(14, 'A Kiss Before You Go');
INSERT INTO Songs VALUES(15, 'I Will Dance (When I Walk Away)');
INSERT INTO Songs VALUES(16, 'Cherry Pie');
INSERT INTO Songs VALUES(17, 'Land of Confusion');
INSERT INTO Songs VALUES(18, 'Lady Marlene');
INSERT INTO Songs VALUES(19, 'Rock-Paper-Scissors');
INSERT INTO Songs VALUES(20, 'Cocktails and Ruby Slippers');
INSERT INTO Songs VALUES(21, 'Soviet Trumpeter');
INSERT INTO Songs VALUES(22, 'Loathsome M');
INSERT INTO Songs VALUES(23, 'Shepherd\'s Song');
INSERT INTO Songs VALUES(24, 'Gypsy Flee');
INSERT INTO Songs VALUES(25, 'God\'s Great Dust Storm');
INSERT INTO Songs VALUES(26, 'Ouch');
INSERT INTO Songs VALUES(27, 'Listening to the World');
INSERT INTO Songs VALUES(28, 'Johnny Blowtorch');
INSERT INTO Songs VALUES(29, 'Flash');
INSERT INTO Songs VALUES(30, 'Driving After You');
INSERT INTO Songs VALUES(31, 'My Own Tune');
INSERT INTO Songs VALUES(32, 'Badlands');
INSERT INTO Songs VALUES(33, 'Old De Spain');
INSERT INTO Songs VALUES(34, 'Oh My God');
INSERT INTO Songs VALUES(35, 'Lady Gray');
INSERT INTO Songs VALUES(36, 'Shine Like Neon Rays');
INSERT INTO Songs VALUES(37, 'Flash in the Dark');
INSERT INTO Songs VALUES(38, 'My Dear');
INSERT INTO Songs VALUES(39, 'Bad Girl');
INSERT INTO Songs VALUES(40, 'Rockland');
INSERT INTO Songs VALUES(41, 'Curvaceous Needs');
INSERT INTO Songs VALUES(42, 'Borka');
INSERT INTO Songs VALUES(43, 'Let it Snow');
