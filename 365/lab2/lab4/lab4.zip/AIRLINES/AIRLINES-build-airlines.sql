-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- AIRLINES-build-airlines.sql

INSERT INTO Airlines Values
   (1, 'United Airlines', 'UAL', 'USA'), 
   (2, 'US Airways', 'USAir', 'USA'), 
   (3, 'Delta Airlines', 'Delta', 'USA'), 
   (4, 'Southwest Airlines', 'Southwest', 'USA'), 
   (5, 'American Airlines', 'American', 'USA'), 
   (6, 'Northwest Airlines', 'Northwest', 'USA'), 
   (7, 'Continental Airlines', 'Continental', 'USA'), 
   (8, 'JetBlue Airways', 'JetBlue', 'USA'), 
   (9, 'Frontier Airlines', 'Frontier', 'USA'), 
   (10, 'AirTran Airways', 'AirTran', 'USA'), 
   (11, 'Allegiant Air', 'Allegiant', 'USA'), 
   (12, 'Virgin America', 'Virgin', 'USA');
