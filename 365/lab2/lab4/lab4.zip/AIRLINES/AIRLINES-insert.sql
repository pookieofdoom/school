-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- AIRLINES-insert.sql

source AIRLINES/AIRLINES-build-airports100.sql
source AIRLINES/AIRLINES-build-airlines.sql
source AIRLINES/AIRLINES-build-flights.sql
