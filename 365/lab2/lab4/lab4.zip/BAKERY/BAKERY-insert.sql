-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- BAKERY-insert.sql

source BAKERY/BAKERY-build-goods.sql
source BAKERY/BAKERY-build-customers.sql
source BAKERY/BAKERY-build-receipts.sql
source BAKERY/BAKERY-build-items.sql