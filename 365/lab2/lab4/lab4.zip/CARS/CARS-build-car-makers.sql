-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CARS-build-car-makers.sql

INSERT INTO CarMakers VALUES
   (1, 'amc', 'American Motor Company', 1),
   (2, 'volkswagen', 'Volkswagen', 2),
   (3, 'bmw', 'BMW', 2),
   (4, 'gm', 'General Motors', 1),
   (5, 'ford', 'Ford Motor Company', 1),
   (6, 'chrysler', 'Chrysler', 1),
   (7, 'citroen', 'Citroen', 3),
   (8, 'nissan', 'Nissan Motors', 4),
   (9, 'fiat', 'Fiat', 5),
   (10, 'hi', 'hi', null),
   (11, 'honda', 'Honda', 4),
   (12, 'mazda', 'Mazda', 4),
   (13, 'daimler benz', 'Daimler Benz', 2),
   (14, 'opel', 'Opel', 2),
   (15, 'peugeaut', 'Peugeaut', 3),
   (16, 'renault', 'Renault', 3),
   (17, 'saab', 'Saab', 6),
   (18, 'subaru', 'Subaru', 4),
   (19, 'toyota', 'Toyota', 4),
   (20, 'triumph', 'Triumph', 7),
   (21, 'volvo', 'Volvo', 6),
   (22, 'kia', 'Kia Motors', 8),
   (23, 'hyundai', 'Hyundai', 8);
