-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CARS-insert.sql

source CARS/CARS-build-continents.sql
source CARS/CARS-build-countries.sql
source CARS/CARS-build-car-makers.sql
source CARS/CARS-build-model-list.sql
source CARS/CARS-build-car-names.sql
source CARS/CARS-build-cars-data.sql
