-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CSU-insert.sql

source CSU/CSU-build-Campuses.sql
source CSU/CSU-build-disciplines.sql
source CSU/CSU-build-degrees.sql
source CSU/CSU-build-discipline-enrollments.sql
source CSU/CSU-build-enrollments.sql
source CSU/CSU-build-faculty.sql
source CSU/CSU-build-csu-fees.sql