-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- INN-insert.sql

source INN/INN-build-Rooms.sql
source INN/INN-build-Reservations.sql
