-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- KATZENJAMMER-insert.sql

source KATZENJAMMER/KATZENJAMMER-build-Band.sql
source KATZENJAMMER/KATZENJAMMER-build-Songs.sql
source KATZENJAMMER/KATZENJAMMER-build-Albums.sql
source KATZENJAMMER/KATZENJAMMER-build-Tracklists.sql
source KATZENJAMMER/KATZENJAMMER-build-Instruments.sql
source KATZENJAMMER/KATZENJAMMER-build-Performance.sql
source KATZENJAMMER/KATZENJAMMER-build-Vocals.sql