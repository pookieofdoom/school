-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- STUDENTS-insert.sql

source STUDENTS/STUDENTS-build-teachers.sql
source STUDENTS/STUDENTS-build-list.sql