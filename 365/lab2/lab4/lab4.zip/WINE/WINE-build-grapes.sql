-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- WINE-build-grapes.sql

INSERT INTO Grapes VALUES(1, 'Barbera', 'Red');
INSERT INTO Grapes VALUES(2, 'Cabernet Franc', 'Red');
INSERT INTO Grapes VALUES(3, 'Cabernet Sauvingnon', 'Red');
INSERT INTO Grapes VALUES(4, 'Chardonnay', 'White');
INSERT INTO Grapes VALUES(5, 'Grenache', 'Red');
INSERT INTO Grapes VALUES(6, 'Malbec', 'Red');
INSERT INTO Grapes VALUES(7, 'Marsanne', 'White');
INSERT INTO Grapes VALUES(8, 'Merlot', 'Red');
INSERT INTO Grapes VALUES(9, 'Mourvedre', 'Red');
INSERT INTO Grapes VALUES(10, 'Muscat', 'White');
INSERT INTO Grapes VALUES(11, 'Petite Sirah', 'Red');
INSERT INTO Grapes VALUES(12, 'Pinot Noir', 'Red');
INSERT INTO Grapes VALUES(13, 'Riesling', 'White');
INSERT INTO Grapes VALUES(14, 'Roussanne', 'White');
INSERT INTO Grapes VALUES(15, 'Sangiovese', 'Red');
INSERT INTO Grapes VALUES(16, 'Sauvignon Blanc', 'White');
INSERT INTO Grapes VALUES(17, 'Syrah', 'Red');
INSERT INTO Grapes VALUES(18, 'Tempranillo', 'Red');
INSERT INTO Grapes VALUES(19, 'Viognier', 'White');
INSERT INTO Grapes VALUES(20, 'Zinfandel', 'Red');
