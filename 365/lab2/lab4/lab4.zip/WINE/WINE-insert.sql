-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- WINE-insert.sql

source WINE/WINE-build-grapes.sql
source WINE/WINE-build-appellations.sql
source WINE/WINE-build-wine.sql