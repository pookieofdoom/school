-- Anthony Dinh
-- adinh03@calpoly.eduj
-- CPE 365
-- WINE-test.sql

SELECT * FROM Grapes;
SELECT COUNT(*) FROM Grapes;

SELECT * FROM Appellations;
SELECT COUNT(*) FROM Appellations;

SELECT * FROM Wine;
SELECT COUNT(*) FROM Wine;