-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- BAKERY-build-customers.sql

INSERT INTO Customers VALUES
   (1,  'LOGAN',  'JULIET'),
   (2,  'ARZT',  'TERRELL'),
   (3,  'ESPOSITA',  'TRAVIS'),
   (4,  'ENGLEY',  'SIXTA'),
   (5,  'DUNLOW',  'OSVALDO'),
   (6,  'SLINGLAND',  'JOSETTE'),
   (7,  'TOUSSAND',  'SHARRON'),
   (8,  'HELING',  'RUPERT'),
   (9,  'HAFFERKAMP',  'CUC'),
   (10,  'DUKELOW',  'CORETTA'),
   (11,  'STADICK',  'MIGDALIA'),
   (12,  'MCMAHAN',  'MELLIE'),
   (13,  'ARNN',  'KIP'),
   (14,  'SOPKO',  'RAYFORD'),
   (15,  'CALLENDAR',  'DAVID'),
   (16,  'CRUZEN',  'ARIANE'),
   (17,  'MESDAQ',  'CHARLENE'),
   (18,  'DOMKOWSKI',  'ALMETA'),
   (19,  'STENZ',  'NATACHA'),
   (20,  'ZEME',  'STEPHEN');
