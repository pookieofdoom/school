-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- BAKERY-insert.sql

source BAKERY-build-goods.sql
source BAKERY-build-customers.sql
source BAKERY-build-receipts.sql
source BAKERY-build-items.sql
