-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CARS-build-continents.sql

INSERT INTO Continents VALUES
   (1, 'america'), 
   (2, 'europe'), 
   (3, 'asia'), 
   (4, 'africa'), 
   (5, 'australia'); 
