-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CSU-build-disciplines.sql

INSERT INTO Disciplines VALUES
   (1, 'Agriculture'),
   (2, 'Architecture'),
   (3, 'Area Studies'),
   (4, 'Biological Sciences'),
   (5, 'Business and Management'),
   (6, 'Communications'),
   (7, 'Computer and Info. Sciences'),
   (8, 'Education'),
   (9, 'Engineering'),
   (10, 'Fine and Applied Arts'),
   (11, 'Foreign Languages'),
   (12, 'Health Professions'),
   (13, 'Home Economics'),
   (14, 'Interdisciplinary Studies'),
   (15, 'Letters'),
   (16, 'Library'),
   (17, 'Mathematics'),
   (18, 'Physical Sciences'),
   (19, 'Psychology'),
   (20, 'Public Affairs'),
   (21, 'Social Sciences'),
   (22, 'Undeclared');
