-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- INN-cleanup.sql

DROP TABLE Reservations;
DROP TABLE Rooms;