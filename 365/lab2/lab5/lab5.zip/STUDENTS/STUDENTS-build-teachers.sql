-- Anthony Dinh
-- adinh03@calpoly,edu
-- CPE 365
-- STUDENTS-build-teachers,sql

INSERT INTO Teachers VALUES
   ('MACROSTIE',  'MIN',  101),
   ('COVIN',  'JEROME',  102),
   ('MOYER',  'OTHA',  103),
   ('NIBLER',  'JERLENE',  104),
   ('MARROTTE',  'KIRK',  105),
   ('TARRING',  'LEIA',  106),
   ('URSERY',  'CHARMAINE',  107),
   ('ONDERSMA',  'LORIA',  108),
   ('KAWA',  'GORDON',  109),
   ('SUMPTION',  'GEORGETTA',  110),
   ('KRIENER',  'BILLIE',  111),
   ('SUGAI',  'ALFREDA',  112);
