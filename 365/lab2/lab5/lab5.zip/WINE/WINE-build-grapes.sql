-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- WINE-build-grapes.sql

INSERT INTO Grapes VALUES
   (1, 'Barbera', 'Red'),
   (2, 'Cabernet Franc', 'Red'),
   (3, 'Cabernet Sauvingnon', 'Red'),
   (4, 'Chardonnay', 'White'),
   (5, 'Grenache', 'Red'),
   (6, 'Malbec', 'Red'),
   (7, 'Marsanne', 'White'),
   (8, 'Merlot', 'Red'),
   (9, 'Mourvedre', 'Red'),
   (10, 'Muscat', 'White'),
   (11, 'Petite Sirah', 'Red'),
   (12, 'Pinot Noir', 'Red'),
   (13, 'Riesling', 'White'),
   (14, 'Roussanne', 'White'),
   (15, 'Sangiovese', 'Red'),
   (16, 'Sauvignon Blanc', 'White'),
   (17, 'Syrah', 'Red'),
   (18, 'Tempranillo', 'Red'),
   (19, 'Viognier', 'White'),
   (20, 'Zinfandel', 'Red');
