-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- WINE-insert.sql

source WINE-build-grapes.sql
source WINE-build-appellations.sql
source WINE-build-wine.sql
