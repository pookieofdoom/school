-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- AIRLINES-insert.sql

source AIRLINES-build-airports100.sql
source AIRLINES-build-airlines.sql
source AIRLINES-build-flights.sql
