-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- INN-insert.sql

source INN-build-Rooms.sql
source INN-build-Reservations.sql
