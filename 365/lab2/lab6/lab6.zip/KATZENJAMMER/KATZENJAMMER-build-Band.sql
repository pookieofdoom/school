-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- KATZENJAMMER-build-Band.sql

INSERT INTO Band VALUES
   (1, 'Solveig', 'Heilo'),
   (2, 'Marianne', 'Sveen'),
   (3, 'Anne-Marit', 'Bergheim'),
   (4, 'Turid', 'Jorgensen');
