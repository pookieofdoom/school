-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- KATZENJAMMER-cleanup.sql

DROP TABLE Vocals;
DROP TABLE Performance;
DROP TABLE Instruments;
DROP TABLE Tracklists;
DROP TABLE Albums;
DROP TABLE Songs;
DROP TABLE Band;