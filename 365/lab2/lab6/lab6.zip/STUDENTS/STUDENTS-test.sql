-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- STUDENTS-test.sql

SELECT * FROM Teachers;
SELECT COUNT(*) FROM Teachers;

SELECT * FROM List;
SELECT COUNT(*) FROM List;