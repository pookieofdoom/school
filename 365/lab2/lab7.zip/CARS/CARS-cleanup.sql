-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- CARS-cleanup.sql


DROP TABLE CarsData;
DROP TABLE CarNames;
DROP TABLE ModelList;
DROP TABLE CarMakers;
DROP TABLE Countries;
DROP TABLE Continents;


