-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- KATZENJAMMER-insert.sql

source KATZENJAMMER-build-Band.sql
source KATZENJAMMER-build-Songs.sql
source KATZENJAMMER-build-Albums.sql
source KATZENJAMMER-build-Tracklists.sql
source KATZENJAMMER-build-Instruments.sql
source KATZENJAMMER-build-Performance.sql
source KATZENJAMMER-build-Vocals.sql
