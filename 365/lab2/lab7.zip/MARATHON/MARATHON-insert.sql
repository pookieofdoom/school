-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- MARATHON-insert.sql

source MARATHON-build-marathon.sql
