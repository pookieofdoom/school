-- Anthony Dinh
-- adinh03@calpoly.edu
-- CPE 365
-- STUDENTS-insert.sql

source STUDENTS-build-teachers.sql
source STUDENTS-build-list.sql
