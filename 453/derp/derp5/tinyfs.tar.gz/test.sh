rm testdisk
make clean
make
./tinyFsDemo
